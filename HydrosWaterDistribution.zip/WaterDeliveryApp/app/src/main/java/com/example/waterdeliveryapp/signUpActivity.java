package com.example.waterdeliveryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.auth.SignInMethodQueryResult;
import com.google.firebase.database.FirebaseDatabase;

import java.util.concurrent.TimeUnit;

public class signUpActivity extends AppCompatActivity {

    EditText etxtusername, etxtpassword, etxtphoneno, etxtemail;
    Button signUPButton;
    ProgressBar progressBar ;
    private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        signUPButton = findViewById(R.id.verifyBtn);
        progressBar = findViewById(R.id.progressBarsignUp);
        progressBar.setVisibility(View.GONE);
        mAuth = FirebaseAuth.getInstance();
        etxtusername = findViewById(R.id.ETusername);
        etxtpassword = findViewById(R.id.ETpassword);
        etxtemail = findViewById(R.id.ETemail);
        etxtphoneno = findViewById(R.id.ETphoneNo);
    }




    public void signUpbtn(View view) {

        progressBar.setVisibility(View.VISIBLE);
        String txtusername = etxtusername.getText().toString().trim();
        String txtpassword = etxtpassword.getText().toString().trim();
        String txtemail = etxtemail.getText().toString().trim();
        String txtphoneno = etxtphoneno.getText().toString().trim();

        if (txtusername.isEmpty()) {
            etxtusername.setError("Enter username");
            etxtusername.requestFocus();
            progressBar.setVisibility(View.GONE);
        }
        if (txtpassword.isEmpty()) {
            etxtpassword.setError("Enter password");
            etxtpassword.requestFocus();
            progressBar.setVisibility(View.GONE);

        }
        if(txtpassword.length() < 6 )
        {
            etxtpassword.setError("Enter at-least 6 characters");
        }
        if (txtemail.isEmpty()) {
            etxtemail.setError("Enter email");
            etxtemail.requestFocus();
            progressBar.setVisibility(View.GONE);

        }
        if (txtphoneno.isEmpty()) {
            etxtphoneno.setError("Enter phone no");
            etxtphoneno.requestFocus();
            progressBar.setVisibility(View.GONE);
        }



        else
        {

            FirebaseAuth.getInstance().fetchSignInMethodsForEmail(txtemail)
                    .addOnCompleteListener(new OnCompleteListener<SignInMethodQueryResult>() {
                        @Override
                        public void onComplete(@NonNull Task<SignInMethodQueryResult> task) {

                            boolean isNewUser = task.getResult().getSignInMethods().isEmpty();

                            if (isNewUser) {
                                progressBar.setVisibility(View.GONE);
                                Intent intent = new Intent(signUpActivity.this ,AddressActivity.class);
                                intent.putExtra("username", txtusername);
                                intent.putExtra("useremail", txtemail);
                                intent.putExtra("userphone", txtphoneno);
                                intent.putExtra("userpass", txtpassword);


                                startActivity(intent);


                            } else {
                                etxtemail.setError("Email is already taken");
                                etxtemail.requestFocus();
                                progressBar.setVisibility(View.GONE);

                            }

                        }
                    });






        }
    };
}
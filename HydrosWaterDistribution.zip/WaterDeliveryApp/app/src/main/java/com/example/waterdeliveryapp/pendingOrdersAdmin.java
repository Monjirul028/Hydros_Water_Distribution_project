package com.example.waterdeliveryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.UiModeManager;
import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class pendingOrdersAdmin extends AppCompatActivity {
    RecyclerView recyclerView;
    LinearLayout linearLayout;
    DatabaseReference databaseReference;
    PendingOrderAdapter pendingOrderAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pending_orders_admin);
        recyclerView = (RecyclerView) findViewById(R.id.pendingOrderRV);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setReverseLayout(true);
        layoutManager.setStackFromEnd(true);

        databaseReference = FirebaseDatabase.getInstance().getReference("PendingOrders");

        FirebaseRecyclerOptions<PendingOrderModel> options =
                new FirebaseRecyclerOptions.Builder<PendingOrderModel>()
                        .setQuery(databaseReference, PendingOrderModel.class)
                        .build();

        pendingOrderAdapter = new PendingOrderAdapter(options, this);
        recyclerView.setLayoutManager(layoutManager);

        recyclerView.setAdapter(pendingOrderAdapter);

    }
    @Override
    protected void onStart() {
        super.onStart();
        pendingOrderAdapter.startListening();
        FirebaseDatabase.getInstance().getReference().addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.hasChild("PendingOrders"))
                {


                }
                else
                {
                    finish();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {


            }
        });
    }


}
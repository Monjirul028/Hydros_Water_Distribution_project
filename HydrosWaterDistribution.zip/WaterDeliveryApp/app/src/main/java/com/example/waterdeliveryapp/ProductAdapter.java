package com.example.waterdeliveryapp;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.FirebaseDatabase;
import com.orhanobut.dialogplus.DialogPlus;
import com.orhanobut.dialogplus.ViewHolder;
import com.squareup.picasso.Picasso;

import java.util.HashMap;
import java.util.Map;


public class ProductAdapter extends FirebaseRecyclerAdapter<Products, ProductAdapter.MyViewHolder> {


    private  Context context;

    public ProductAdapter(@NonNull FirebaseRecyclerOptions<Products> options, Context context) {
        super(options);
        this.context = context;
    }

    @Override
    protected void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position, @NonNull Products model) {

        holder.productName.setText(model.getName());
        holder.productSize.setText("( " + model.getSize() +" )");
        holder.productPrice.setText("₹" + model.getPrice()+"/-");
        holder.productPQ.setText(model.getPricePerQuantity());

        Picasso.get().load(model.getImage()).into(holder.productImage);


        holder.productDeleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which){
                            case DialogInterface.BUTTON_POSITIVE:
                                FirebaseDatabase.getInstance().getReference()
                                     .child("Products").child(getRef(position).getKey())
                                 .setValue(null)
                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {

                                }
                                });
                                break;

                            case DialogInterface.BUTTON_NEGATIVE:

                                break;
                        }
                    }
                };
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setMessage("Are you sure?").setPositiveButton("Yes", dialogClickListener)
                        .setNegativeButton("No", dialogClickListener).show();



            }
        });

        holder.productEditBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                final DialogPlus dialog = DialogPlus.newDialog(context)
                        .setGravity(Gravity.CENTER)
                        .setMargin(50,0,50,0)
                        .setContentHolder(new ViewHolder(R.layout.edit_product_dialog_item))
                        .setExpanded(false)  // This will enable the expand feature, (similar to android L share dialog)
                        .create();

                View holderView = (LinearLayout)dialog.getHolderView();


                final  EditText name = holderView.findViewById(R.id.UpdateProductNameET);
                final  EditText  size = holderView.findViewById(R.id.UpdateProductSizeET);
                final  EditText  price = holderView.findViewById(R.id.UpdateProductPriceET);
                final  EditText  ProductPq = holderView.findViewById(R.id.UpdateProductPricePQET);

                final ImageView productImageUpdate = holderView.findViewById(R.id.UpdateProductIV);

                name.setText(model.getName());
                size.setText(model.getSize());
                price.setText(model.getPrice());
                ProductPq.setText(model.getPricePerQuantity());

                Button update = holderView.findViewById(R.id.update);

                update.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        Map<String,Object> map = new HashMap<>();
                        map.put("name",name.getText().toString());
                        map.put("size",size.getText().toString());
                        map.put("price",price.getText().toString());
                        map.put("pricePQ",ProductPq.getText().toString());

                        FirebaseDatabase.getInstance().getReference()
                                .child("Products")
                                .child(getRef(position).getKey())
                                .updateChildren(map)
                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        dialog.dismiss();
                                    }
                                });
                    }
                });
                dialog.show();
            }
        });
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.singleproduct,parent,false);
        return new MyViewHolder(v);
    }


    class MyViewHolder extends RecyclerView.ViewHolder{

        TextView productName,productSize,productPrice,productPQ;
        ImageView productImage, productEditBtn,productDeleteBtn;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            productImage=  itemView.findViewById(R.id.productIv);
           productName = itemView.findViewById(R.id.productNameTv);
           productSize = itemView.findViewById(R.id.productSizeTv);
           productPrice = itemView.findViewById(R.id.productPriceTv);
           productPQ = itemView.findViewById(R.id.productPQTv);
           productEditBtn = itemView.findViewById(R.id.EditProductBTn);
           productDeleteBtn = itemView.findViewById(R.id.DeleteProductBTn);
        }
    }

}
package com.example.waterdeliveryapp;

import static android.content.ContentValues.TAG;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.orhanobut.dialogplus.DialogPlus;
import com.orhanobut.dialogplus.ViewHolder;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class cartFragment extends Fragment {

    LinearLayout LayoutCheckout, TVcart;
    TextView totalAmountTV, checkoutBtnTV;
    addressModel model;
    String userID;
    int Total =0;
    Map<String, Object> map = new HashMap<>();


    RecyclerView recyclerView;
    DatabaseReference databaseReference;

    private cartItemAdapter CartItemAdapter;

    public cartFragment() {

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        View v = inflater.inflate(R.layout.fragment_cart, container, false);

        totalAmountTV = v.findViewById(R.id.TotalAmountTV);
        checkoutBtnTV = v.findViewById(R.id.checkOutBtn);
        TVcart = v.findViewById(R.id.TextViewCart);

        LayoutCheckout = v.findViewById(R.id.layoutTotalCheckout);

        userID = FirebaseAuth.getInstance().getCurrentUser().getUid();

        databaseReference = FirebaseDatabase.getInstance().getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid());

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.child("TotalAmount").getValue().toString().equals("0")) {
                    LayoutCheckout.setVisibility(View.GONE);
                    TVcart.setVisibility(View.VISIBLE);
                } else {

                    LayoutCheckout.setVisibility(View.VISIBLE);
                    TVcart.setVisibility(View.GONE);
                    totalAmountTV.setText("Total amount: ₹" + snapshot.child("TotalAmount").getValue().toString() + ".00");
                    Total = Integer.valueOf(snapshot.child("TotalAmount").getValue().toString());
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        //Placing order
        checkoutBtnTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                final DialogPlus dialog = DialogPlus.newDialog(getActivity())
                        .setGravity(Gravity.CENTER)
                        .setMargin(50, 0, 50, 0)
                        .setContentHolder(new ViewHolder(R.layout.edit_address_dialog_item))
                        .setExpanded(false)  // This will enable the expand feature, (similar to android L share dialog)
                        .create();

                View holderView = dialog.getHolderView();

                EditText shopName = holderView.findViewById(R.id.updateShopName);
                EditText Area = holderView.findViewById(R.id.updateArea);
                EditText streetName = holderView.findViewById(R.id.updateStreetName);
                EditText landmark = holderView.findViewById(R.id.updateLandmark);
                EditText phoneNo = holderView.findViewById(R.id.updatePhoneNo);
                EditText pin = holderView.findViewById(R.id.updatePin);

                DatabaseReference cartRef = FirebaseDatabase.getInstance().getReference("Cart").child(FirebaseAuth.getInstance().getCurrentUser().getUid());

                DatabaseReference OrderRef = FirebaseDatabase.getInstance().getReference("Orders").child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                        ;

                FirebaseDatabase.getInstance().getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid().toString())
                        .child("Address").addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                model = snapshot.getValue(addressModel.class);
                                shopName.setText(model.getShopName());
                                Area.setText(model.getArea());
                                streetName.setText(model.getStreetName());
                                landmark.setText(model.getLandmark());
                                phoneNo.setText(model.getMobileNo());
                                pin.setText(model.getPin());
                            }
                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                            }
                        });
                Button update = holderView.findViewById(R.id.update);

                update.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        if (shopName.getText().toString().isEmpty()) {
                            shopName.setError("Enter shop name");
                            shopName.requestFocus();
                        } else if (Area.getText().toString().isEmpty()) {
                            Area.setError("Enter Area");
                            Area.requestFocus();
                        } else if (streetName.getText().toString().isEmpty()) {
                            streetName.setError("Enter street name");
                            streetName.requestFocus();
                        } else if (landmark.getText().toString().isEmpty()) {
                            landmark.setError("Enter landmark");
                            landmark.requestFocus();
                        } else if (phoneNo.getText().toString().isEmpty() || phoneNo.getText().toString().length() < 10 || phoneNo.getText().toString().length() > 12) {
                            phoneNo.setError("Enter phone no");
                            phoneNo.requestFocus();
                        }
                        else if (pin.getText().toString().isEmpty() || pin.getText().toString().length() != 6 ) {
                            pin.setError("Enter valid pin");
                            pin.requestFocus();
                        }



                        else {

                        map.put("shopName", shopName.getText().toString());
                        map.put("area", Area.getText().toString());
                        map.put("streetName", streetName.getText().toString());
                        map.put("landmark", landmark.getText().toString());
                        map.put("mobileNo", phoneNo.getText().toString());
                        map.put("pin", pin.getText().toString());

                        FirebaseDatabase.getInstance().getReference("Users")
                                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                .child("Address")
                                .updateChildren(map)
                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        dialog.dismiss();
                                        copyRecord(cartRef, OrderRef);
                                        cartRef.setValue(null);
                                        Toast.makeText(getContext(), "Order placed", Toast.LENGTH_SHORT).show();
                                    }
                                });
                    }
                    }
                });
                dialog.show();
            }

        });

        return v;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView = (RecyclerView) getActivity().findViewById(R.id.cartRecyclerView);
        databaseReference = FirebaseDatabase.getInstance().getReference("Cart").child(FirebaseAuth.getInstance().getCurrentUser().getUid());
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        FirebaseRecyclerOptions<Products> options =
                new FirebaseRecyclerOptions.Builder<Products>()
                        .setQuery(databaseReference, Products.class)
                        .build();
        CartItemAdapter = new cartItemAdapter(options, getContext());
        recyclerView.setAdapter(CartItemAdapter);

    }

    @Override
    public void onStart() {
        super.onStart();
        CartItemAdapter.startListening();
    }




    private void copyRecord(DatabaseReference cartRef, final DatabaseReference orderRef) {

        String orderId = orderRef.push().getKey();
        String nOrderId =String.valueOf( System.currentTimeMillis());
        ValueEventListener valueEventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
                DatabaseReference OrdersRef = rootRef;

                final String saveCurrentDate, saveCurrentTime;

                Calendar calforDate = Calendar.getInstance();
                SimpleDateFormat currentDate = new SimpleDateFormat("MMM dd,yyyy");
                saveCurrentDate = currentDate.format(calforDate.getTime());

                SimpleDateFormat currentTime = new SimpleDateFormat("HH:mm:ss a");
                saveCurrentTime = currentTime.format(calforDate.getTime());

                orderRef.child(nOrderId).child("Items").setValue(dataSnapshot.getValue()).addOnCompleteListener(new OnCompleteListener<Void>() {

                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isComplete()) {
                            orderRef.child(nOrderId).child("OrderId").setValue(nOrderId);
                            orderRef.child(nOrderId).child("Date").setValue(saveCurrentDate);
                            orderRef.child(nOrderId).child("Time").setValue(saveCurrentTime);
                            orderRef.child(nOrderId).child("Status").setValue("Confirmed");
                            orderRef.child(nOrderId).child("TotalPrice").setValue(String.valueOf(Total));

                            rootRef.child("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("TotalAmount").setValue(0);
                        } else {
                            Log.d(TAG, "Copy failed!");
                        }
                    }
                });

                //Pending Orders
                OrdersRef.child("PendingOrders").child(nOrderId).child("Items").setValue(dataSnapshot.getValue()).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        OrdersRef.child("PendingOrders").child(nOrderId).child("OrderId").setValue(nOrderId);
                        OrdersRef.child("PendingOrders").child(nOrderId).child("Date").setValue(saveCurrentDate);
                        OrdersRef.child("PendingOrders").child(nOrderId).child("Time").setValue(saveCurrentTime);
                        OrdersRef.child("PendingOrders").child(nOrderId).child("Status").setValue("Pending");
                        OrdersRef.child("PendingOrders").child(nOrderId).child("Address").setValue(map);
                        OrdersRef.child("PendingOrders").child(nOrderId).child("Total").setValue(String.valueOf(Total));
                        OrdersRef.child("PendingOrders").child(nOrderId).child("UserId").setValue(userID);
                    }
                });
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.d("TAG", databaseError.getMessage()); //Never ignore potential errors!
            }
        };
        cartRef.addListenerForSingleValueEvent(valueEventListener);
    }

}

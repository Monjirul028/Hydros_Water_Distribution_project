package com.example.waterdeliveryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.SignInMethodQueryResult;

public class ForgotPasswordActivity extends AppCompatActivity {
    EditText emailET;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        emailET = findViewById(R.id.emailETforgotPass);
        progressBar = findViewById(R.id.progressBar3);
        progressBar.setVisibility(View.GONE);

    }

    public void sendLinkBtn(View view) {
        progressBar.setVisibility(View.VISIBLE);
        String email =  emailET.getText().toString();
        if( email.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(email).matches())
        {
            emailET.setError("Enter valid username");
            emailET.requestFocus();
            progressBar.setVisibility(View.GONE);
        }

        else
        {
            FirebaseAuth.getInstance().fetchSignInMethodsForEmail(email)
                    .addOnCompleteListener(new OnCompleteListener<SignInMethodQueryResult>() {
                        @Override
                        public void onComplete(@NonNull Task<SignInMethodQueryResult> task) {

                            boolean isNewUser = task.getResult().getSignInMethods().isEmpty();

                            if (isNewUser) {
                                emailET.setError("Invalid email");
                                emailET.requestFocus();
                                progressBar.setVisibility(View.GONE);
                            }

                            else {

                                FirebaseAuth.getInstance().sendPasswordResetEmail(email).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        progressBar.setVisibility(View.GONE);

                                        Toast.makeText(ForgotPasswordActivity.this, "An email has sent to your email", Toast.LENGTH_LONG).show();
                                    }
                                });
                            }
                        }
                    });
        }
    }

    public void goTologinBtn(View view) {
        Intent intent = new Intent(this , signInActivity.class);
        startActivity(intent);
        finishAffinity();
    }

    public void goToSignUpBtn(View view) {
        Intent intent = new Intent(this , signUpActivity.class);
        startActivity(intent);
        finishAffinity();
    }
}
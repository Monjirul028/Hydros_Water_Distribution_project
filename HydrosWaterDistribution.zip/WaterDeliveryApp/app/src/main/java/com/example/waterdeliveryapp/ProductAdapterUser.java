package com.example.waterdeliveryapp;
import android.content.Context;
import android.annotation.SuppressLint;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

public class ProductAdapterUser extends FirebaseRecyclerAdapter<Products, ProductAdapterUser.MyViewHolder> {
    int grandTotal;
    private  Context context;


    public ProductAdapterUser(@NonNull FirebaseRecyclerOptions<Products> options, Context context) {
        super(options);
        this.context = context;
    }

    @Override
    protected void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position, @NonNull Products products) {


        holder.productName.setText(products.getName()+" (" + products.getSize() +")");
        holder.productPrice.setText("₹" + products.getPrice()+"/-");
        holder.productPQ.setText(products.getPricePerQuantity());
        Picasso.get().load(products.getImage()).into(holder.productImage);

        holder.addToCartBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DatabaseReference itemRef = FirebaseDatabase.getInstance().getReference("Cart").child(FirebaseAuth.getInstance().getCurrentUser().getUid().toString());

                itemRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                        if (snapshot.hasChild(getRef(position).getKey()))
                        {
                            //Toast.makeText(context, "Already exists", Toast.LENGTH_SHORT).show();
                        }

                        else
                        {

                            //start
                            FirebaseDatabase.getInstance().getReference("Cart").child(FirebaseAuth.getInstance().getCurrentUser().getUid().toString())
                                  .child(getRef(position).getKey()).setValue(products).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            Toast toast= Toast.makeText(view.getContext(), "Added to Cart", Toast.LENGTH_SHORT);
                                            toast.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL, 0, 0);
                                            toast.show();



                                            FirebaseDatabase.getInstance().getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                                    .addListenerForSingleValueEvent(new ValueEventListener() {
                                                        @Override
                                                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                            grandTotal = Integer.valueOf(snapshot.child("TotalAmount").getValue().toString());

                                                            FirebaseDatabase.getInstance().getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("TotalAmount")
                                                                    .setValue(grandTotal + Integer.valueOf(products.getPrice())).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                        @Override
                                                                        public void onComplete(@NonNull Task<Void> task) {
                                                                        }
                                                                    });
                                                        }

                                                        @Override
                                                        public void onCancelled(@NonNull DatabaseError error) {

                                                        }
                                                    });


                                        }
                                    });
                            //end

                            itemRef.child(getRef(position).getKey()).child("totalPrice").setValue(products.getPrice());
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.home_page_single_item,parent,false);

        return new MyViewHolder(v);
    }


    class MyViewHolder extends RecyclerView.ViewHolder{

        TextView productName,productSize,productPrice,productPQ;
        Button addToCartBtn;
        ImageView productImage;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            productImage=  itemView.findViewById(R.id.singleItemImageView);
            productName = itemView.findViewById(R.id.productNameSingleItemTv);
            productPrice = itemView.findViewById(R.id.product_price_single_item);
            productPQ = itemView.findViewById(R.id.product_quantity_SingleItemTv);
            addToCartBtn = itemView.findViewById(R.id.addToCartButton);

        }
    }

    @Override
    public void onDataChanged() {
        super.onDataChanged();
    }

}


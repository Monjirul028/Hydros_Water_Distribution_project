package com.example.waterdeliveryapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DeliveredProductDetails extends AppCompatActivity {
    PendingOrderModel pendingOrderModel;
    String userID, orderID, total, date, time;
    TextView shopName, area, streetName, mobileNo, Landmark, Pin;
    TextView orderIDTv, orderDateTv, orderTimeTv, orderTotalTv;
    TextView confirmOrder;
    private DatabaseReference databaseReference;
    addressModel addModel;
    RecyclerView recyclerView;
    private OrderItemAdapter orderItemAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivered_product_details);

        userID = getIntent().getStringExtra("userID");
        orderID = getIntent().getStringExtra("orderId");
        total = getIntent().getStringExtra("total");
        date = getIntent().getStringExtra("date");
        time = getIntent().getStringExtra("time");

        orderIDTv = findViewById(R.id.pendingOrderID);
        orderDateTv = findViewById(R.id.pendingOrderDate);
        orderTimeTv = findViewById(R.id.pendingOrderTime);
        orderTotalTv = findViewById(R.id.pendingOrderTotalAmount);
        recyclerView = findViewById(R.id.pendingOrderRecyclerView);
        recyclerView.setNestedScrollingEnabled(false);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        shopName = findViewById(R.id.pendingOrderShopName);
        area = findViewById(R.id.pendingOrderArea);
        mobileNo = findViewById(R.id.pendingOrderMobileNo);
        Landmark = findViewById(R.id.pendingOrderLandmark);
        streetName = findViewById(R.id.pendingOrderStreetName);
        Pin = findViewById(R.id.pendingOrderPin);
        confirmOrder = findViewById(R.id.confirmOrderTv);


        orderIDTv.setText(orderID);
        orderDateTv.setText(date);
        orderTimeTv.setText(time);
        orderTotalTv.setText(total);

        databaseReference = FirebaseDatabase.getInstance().getReference("DeliveredOrders")
                .child(orderID);

        FirebaseRecyclerOptions<Products> options =
                new FirebaseRecyclerOptions.Builder<Products>()
                        .setQuery(databaseReference.child("Items"), Products.class)
                        .build();

        orderItemAdapter = new OrderItemAdapter(options, this);
        recyclerView.setAdapter(orderItemAdapter);

        databaseReference.child("Address").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                addressModel addressModel = snapshot.getValue(com.example.waterdeliveryapp.addressModel.class);
                area.setText(addressModel.getArea());
                Landmark.setText(addressModel.getLandmark());
                shopName.setText(addressModel.getShopName());
                streetName.setText(addressModel.getStreetName());
                Pin.setText(addressModel.getPin());
                mobileNo.setText(addressModel.getMobileNo());

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

                Intent intent = new Intent(DeliveredProductDetails.this, orderHistoryAdmin.class);
                startActivity(intent);
                finish();

            }
        });
    }
    @Override
    protected void onStart() {
        super.onStart();
        orderItemAdapter.startListening();
    }








}

package com.example.waterdeliveryapp;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;

import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Timestamp;


public class addProduct extends AppCompatActivity {
    ImageView addPIcond;
    ProgressBar progressBar;
    EditText id, name, price, pricePQ;
    String sizeText, nameText, priceText, pricePQtext,imgtxt;

    //Permission:
    private  static final int CAMERA_REQUEST_CODE = 200;
    private static final int STORAGE_REQUEST_CODE = 300;

    private static final int IMAGE_PICK_GALLERY_CODE = 400;
    private static final int IMAGE_PICK_CAMERA_CODE = 500;

    private String[] cameraPermissions;
    private String[] storagePermissions;

    private Uri image_uri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);



        progressBar = findViewById(R.id.progressBarAddProduct);
        progressBar.setVisibility(View.GONE);
        addPIcond = findViewById(R.id.addProductIcon);
        id = findViewById(R.id.productSize);
        name = findViewById(R.id.productNameEt);
        price = findViewById(R.id.productPrice);
        pricePQ = findViewById(R.id.productPricePQ);

        cameraPermissions = new String[] {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE};
        storagePermissions = new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE};

        addPIcond.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                showImagePickDialog();
            }
        });

    }

    private void showImagePickDialog() {
        String [] options = {"Gallery"};
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Pick image")
                .setItems(options, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {


                            if (checkStoragePermission())
                            {
                                pickFromGallery();
                            }
                            else
                            {
                                requestStoragePermission();
                            }
                    }
                }).show();
    }
    private void pickFromGallery()
    {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent,IMAGE_PICK_GALLERY_CODE);
    }



    private boolean checkStoragePermission()
    {
        boolean result = ContextCompat.checkSelfPermission(this,Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                (PackageManager.PERMISSION_GRANTED);
        return result;
    }
    private void requestStoragePermission()
    {
        ActivityCompat.requestPermissions(this, storagePermissions,STORAGE_REQUEST_CODE);
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        switch (requestCode)
        {

            case STORAGE_REQUEST_CODE:
            {
                if (grantResults.length>0)
                {
                    boolean storageAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    if (storageAccepted){
                        pickFromGallery();
                    }
                    else
                    {
                        Toast.makeText(this, "Storage permission required", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        if (resultCode == RESULT_OK)
        {
            if (requestCode == IMAGE_PICK_GALLERY_CODE)
            {
                image_uri = data.getData();
                addPIcond.setImageURI(image_uri);
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }


    public void AddProductBtn(View view) {
        progressBar.setVisibility(View.VISIBLE);

        sizeText = id.getText().toString();
        nameText = name.getText().toString();
        priceText = price.getText().toString();
        pricePQtext = pricePQ.getText().toString();

        if (sizeText.isEmpty()) {
            id.setError("Enter ID");
            id.requestFocus();
            progressBar.setVisibility(View.GONE);
        }
        if (nameText.isEmpty()) {
            name.setError("Enter name of the product");
            name.requestFocus();
            progressBar.setVisibility(View.GONE);
        }
        if (priceText.isEmpty()) {
            price.setError("Set a price");
            price.requestFocus();
            progressBar.setVisibility(View.GONE);
        }
        if (pricePQtext.isEmpty()) {
            pricePQ.setError("Enter quantity");
            pricePQ.requestFocus();
            progressBar.setVisibility(View.GONE);
        }
        if (image_uri == null) {
            Toast.makeText(this, "Please select an image", Toast.LENGTH_SHORT).show();
            progressBar.setVisibility(View.GONE);
        } else {

            String filePathName = "Product_images/" + "" + nameText;

            StorageReference storageReference = FirebaseStorage.getInstance().getReference(filePathName);

            storageReference.putFile(image_uri)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            Task<Uri> uriTask = taskSnapshot.getStorage().getDownloadUrl();
                            while (!uriTask.isSuccessful()) ;
                            Uri downloadImageUri = uriTask.getResult();

                            if (uriTask.isSuccessful()) {
                                Products newProduct = new Products(nameText, sizeText, pricePQtext, downloadImageUri.toString(), priceText, priceText, "1");

                                DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
                                DatabaseReference quizRef = rootRef.child("Products");
                                String key = quizRef.push().getKey();
                                quizRef.child(key).setValue(newProduct).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        progressBar.setVisibility(View.GONE);


                                        Toast.makeText(addProduct.this, "Product added", Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(addProduct.this, addProduct.class);
                                        startActivity(intent);
                                        finish();

                                    }
                                });
                            }
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(addProduct.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });

        }
    }


}

package com.example.waterdeliveryapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class profileFragment extends Fragment {

    String phone, email, username;
    DatabaseReference myref;

    TextView shopName_var, shopEmailvar, shopPhvar, textViewlogout;

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";


    private String mParam1;
    private String mParam2;

    public profileFragment() {
        // Required empty public constructor
    }


    public static profileFragment newInstance(String param1, String param2) {
        profileFragment fragment = new profileFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_profile, container, false);




        return view;
    }



    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        shopName_var = view.findViewById(R.id.shopNmaePF);
        shopEmailvar = view.findViewById(R.id.shopEmailPF);
        shopPhvar = view.findViewById(R.id.shopPhonePF);
        textViewlogout = view.findViewById(R.id.textViewLogout);
        textViewlogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which){
                            case DialogInterface.BUTTON_POSITIVE:
                                FirebaseAuth.getInstance().signOut();
                                Toast.makeText(getContext(), "Logging out", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getContext(), WelcomeActivity.class);
                                startActivity(intent);
                                getActivity().finishAffinity();

                                break;

                            case DialogInterface.BUTTON_NEGATIVE:

                                break;
                        }
                    }
                };
                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                builder.setMessage("Are you sure?").setPositiveButton("Yes", dialogClickListener)
                        .setNegativeButton("No", dialogClickListener).show();

            }
        });


        FirebaseAuth myfirebaseAuth = FirebaseAuth.getInstance();

        if (myfirebaseAuth.getCurrentUser() != null) {

            //Retrieve data
            FirebaseUser cUser = myfirebaseAuth.getCurrentUser();
            String uID = cUser.getUid();

            DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users").child(uID);


            reference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {

                    username = snapshot.child("username").getValue().toString();
                    email = snapshot.child("useremail").getValue().toString();
                    phone = snapshot.child("userphoneno").getValue().toString();


                    shopName_var.setText(username);
                    shopEmailvar.setText(email);
                    shopPhvar.setText(phone);

                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });


        }

    }



}
package com.example.waterdeliveryapp;

public class UserOrderModel {
    String OrderId;
    String Date;
    Products products;
    String Time;
    String Status;
    String TotalPrice;

    public UserOrderModel(String orderId, String date, Products products, String time, String status, String totalPrice) {
        OrderId = orderId;
        Date = date;
        this.products = products;
        Time = time;
        Status = status;
        TotalPrice = totalPrice;
    }

    public UserOrderModel()
    {

    }

    public String getOrderId() {
        return OrderId;
    }

    public void setOrderId(String orderId) {
        OrderId = orderId;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public Products getProducts() {
        return products;
    }

    public void setProducts(Products products) {
        this.products = products;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        Time = time;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public String getTotalPrice() {
        return TotalPrice;
    }

    public void setTotalPrice(String totalPrice) {
        TotalPrice = totalPrice;
    }
}

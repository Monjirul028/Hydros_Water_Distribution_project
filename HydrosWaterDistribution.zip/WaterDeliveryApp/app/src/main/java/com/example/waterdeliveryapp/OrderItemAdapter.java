package com.example.waterdeliveryapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.squareup.picasso.Picasso;

public class OrderItemAdapter extends FirebaseRecyclerAdapter<Products,OrderItemAdapter.MyViewHolder> {
    Context context;
    public OrderItemAdapter(@NonNull FirebaseRecyclerOptions<Products> options, Context context) {
        super(options);
        this.context = context;
    }

    @Override
    protected void onBindViewHolder(@NonNull OrderItemAdapter.MyViewHolder holder, int position, @NonNull Products model) {


        Picasso.get().load(model.getImage()).into(holder.productImage);
        holder.productName.setText(model.getName());
        holder.productPrice.setText("Price: ₹"+model.getPrice());
        holder.productQuantity.setText("Qty: " +model.getOrderQuantity());
        holder.productTotalPrice.setText("Total Price: ₹"+model.getTotalPrice());
    }

    @NonNull
    @Override
    public OrderItemAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.user_order_item_rv,parent,false);
        return new MyViewHolder(v);
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView productName, productTotalPrice, productQuantity,productPrice;
        ImageView productImage;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            productName = itemView.findViewById(R.id.userOrderItemName);
            productPrice = itemView.findViewById(R.id.userOrderItemPrice);
            productTotalPrice = itemView.findViewById(R.id.userOrderItemTotal);
            productQuantity = itemView.findViewById(R.id.userOrderItemQuantity);
            productImage = itemView.findViewById(R.id.userOrderItemImage);
        }
    }
}

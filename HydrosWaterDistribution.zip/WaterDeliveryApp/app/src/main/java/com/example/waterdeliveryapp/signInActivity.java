package com.example.waterdeliveryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.SignInMethodQueryResult;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class signInActivity extends AppCompatActivity {
    EditText username,password;
    ProgressBar progressBar;
    Button loginbtn;
    FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
    loginbtn=findViewById(R.id.loginbtn);
        progressBar = findViewById(R.id.progressBar);
        progressBar.setVisibility(View.GONE);
        username = findViewById(R.id.ETusernamelgin);
        password = findViewById(R.id.ETpasswordlgin);
        mAuth = FirebaseAuth.getInstance();
    }


    public  void signInbtn(View view)
    {
        loginbtn.setEnabled(false);

        String uname = username.getText().toString().trim();
        String pass = password.getText().toString().trim();


        if( uname.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(uname).matches())
        {
            username.setError("Enter valid email");
            username.requestFocus();
            loginbtn.setEnabled(true);
        }
        else if(pass.isEmpty() || pass.length()<6)
        {
            password.setError("Enter password");
            password.requestFocus();
            loginbtn.setEnabled(true);

        }

        else{
        progressBar.setVisibility(View.VISIBLE);

        mAuth.fetchSignInMethodsForEmail(uname).addOnCompleteListener(new OnCompleteListener<SignInMethodQueryResult>() {
            @Override
            public void onComplete(@NonNull Task<SignInMethodQueryResult> task) {
                boolean check = !task.getResult().getSignInMethods().isEmpty();

                if (check) {
                    mAuth.signInWithEmailAndPassword(uname, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                progressBar.setVisibility(View.GONE);

                                if (FirebaseAuth.getInstance().getCurrentUser().isEmailVerified()) {

                                    FirebaseUser cUser = FirebaseAuth.getInstance().getCurrentUser();
                                    String uID = cUser.getUid();

                                    DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users").child(uID);

                                    reference.addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot snapshot) {

                                            Boolean userType = (Boolean) snapshot.child("userRole").getValue();

                                            if (userType == Boolean.TRUE) {
                                                Intent intent = new Intent(signInActivity.this, AdminHomePage.class);
                                                startActivity(intent);
                                                finishAffinity();
                                            } else {
                                                Intent intent1 = new Intent(signInActivity.this, HomePage.class);
                                                startActivity(intent1);
                                                finishAffinity();
                                            }

                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError error) {
                                            Toast.makeText(signInActivity.this, "Check internet connection", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                                } else {
                                    FirebaseDatabase.getInstance().getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                            .removeValue();

                                    FirebaseAuth.getInstance().getCurrentUser().delete();

                                    progressBar.setVisibility(View.GONE);
                                    loginbtn.setEnabled(true);

                                    Toast.makeText(signInActivity.this, "You don't have an account", Toast.LENGTH_SHORT).show();

                                }

                            } else {
                                progressBar.setVisibility(View.GONE);
                                loginbtn.setEnabled(true);

                                Toast.makeText(signInActivity.this, "Wrong Password", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

                } else {
                    progressBar.setVisibility(View.GONE);
                    loginbtn.setEnabled(true);

                    Toast.makeText(signInActivity.this, "You don't have an account", Toast.LENGTH_SHORT).show();
                }

            }



        });



    }
    }

    public  void forgotbtn(View view)
    {
        Intent intent = new Intent(this, ForgotPasswordActivity.class);
        startActivity(intent);
    }
    

}
package com.example.waterdeliveryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.FirebaseDatabase;

public class otpVerification extends AppCompatActivity {

    String username, userEmail, userPhone, userpass;
    String shopName, shopArea, shopLandmark, shopStreet, shopPhone, shopPin;
    TextView resendOTP;
    Button verifyOTP;
    ProgressBar progressBar;
    FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp_verification);

        progressBar = findViewById(R.id.progressBar2);
        progressBar.setVisibility(View.GONE);
        resendOTP = findViewById(R.id.resendOTPbtn);
        verifyOTP = findViewById(R.id.verifyOtpBtn);
        firebaseAuth = FirebaseAuth.getInstance();

        username = getIntent().getStringExtra("username");
        userEmail = getIntent().getStringExtra("useremail");
        userPhone = getIntent().getStringExtra("userphone");
        userpass = getIntent().getStringExtra("userpass");
        shopName = getIntent().getStringExtra("shopName");
        shopArea = getIntent().getStringExtra("shopArea");
        shopStreet = getIntent().getStringExtra("streetName");
        shopLandmark = getIntent().getStringExtra("landmark");
        shopPhone = getIntent().getStringExtra("phone");
        shopPin = getIntent().getStringExtra("pin");


        firebaseAuth.createUserWithEmailAndPassword(userEmail, userpass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                firebaseAuth.getCurrentUser().sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {

                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(otpVerification.this, "Verification Email Sent", Toast.LENGTH_SHORT).show();


                    }
                });


            }
        });


        resendOTP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                FirebaseAuth.getInstance().getCurrentUser().sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                    }
                });

            }
        });


        verifyOTP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseUser firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
                firebaseUser.reload();
                if (!firebaseUser.isEmailVerified()) {
                    Toast.makeText(otpVerification.this, "Please verify your email", Toast.LENGTH_SHORT).show();
                } else
                {
                    addressModel model = new addressModel(shopName, shopArea, shopStreet, shopLandmark, shopPhone, shopPin);
                    User user = new User(username, userpass, userEmail, userPhone, Boolean.FALSE);
                    FirebaseDatabase.getInstance().getReference("Users")
                            .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                            .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>()
                            {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {

                                        FirebaseDatabase.getInstance().getReference("Users")
                                                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                                .child("TotalAmount").setValue(0);

                                        FirebaseDatabase.getInstance().getReference("Users")
                                                .child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("Address")
                                                .setValue(model);


                                        Intent intent = new Intent(otpVerification.this, HomePage.class);
                                        startActivity(intent);

                                        finishAffinity();


                                    } else {

                                    }

                                }
                            });
                }
            }
        });
    }
}



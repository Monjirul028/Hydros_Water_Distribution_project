package com.example.waterdeliveryapp;



import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class DeliveredOrderAdapter extends FirebaseRecyclerAdapter<PendingOrderModel, DeliveredOrderAdapter.MyViewHolder> {
    Context context;

    public DeliveredOrderAdapter(@NonNull FirebaseRecyclerOptions<PendingOrderModel> options, Context context) {
        super(options);
        this.context = context;
    }
    @Override
    protected void onBindViewHolder(@NonNull DeliveredOrderAdapter.MyViewHolder holder, int position, @NonNull PendingOrderModel model) {

        holder.pendingOrderPrice.setText(model.getTotal());
        //holder.pendingOrderDate.setText(model.getDate());
        holder.pendingOrderID.setText(model.getOrderId());

        String userId = model.getUserId();

        FirebaseDatabase.getInstance().getReference("Users").child(userId)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        holder.pendingOrderShopName.setText(snapshot.child("username").getValue().toString());
                        holder.pendingOrderPhone.setText(snapshot.child("userphoneno").getValue().toString());
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
        FirebaseDatabase.getInstance().getReference("DeliveredOrders").child(model.getOrderId()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                    holder.pendingOrderDate.setText(snapshot.child("Status").getValue().toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
       holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, DeliveredProductDetails.class);
                intent.putExtra("orderId",model.getOrderId());
                intent.putExtra("total",model.getTotal());
                intent.putExtra("date", model.getDate());
                intent.putExtra("userID",model.getUserId());
                intent.putExtra("time",model.getTime());
                view.getContext().startActivity(intent);
            }
        });

    }

    @NonNull
    @Override
    public DeliveredOrderAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.single_delivered_order,parent,false);
        return new DeliveredOrderAdapter.MyViewHolder(v);
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView pendingOrderShopName, pendingOrderPrice, pendingOrderDate, pendingOrderID, pendingOrderPhone;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            pendingOrderShopName = itemView.findViewById(R.id.pendingOrderUsername);
            pendingOrderID = itemView.findViewById(R.id.pendingOrderID);
            pendingOrderDate = itemView.findViewById(R.id.pendingOrderDate);
            pendingOrderPhone = itemView.findViewById(R.id.pendingOrderPhoneNo);
            pendingOrderPrice = itemView.findViewById(R.id.pendingOrderTotalTv);
        }
    }
}

package com.example.waterdeliveryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;

public class EmailVerificationAdmin extends AppCompatActivity {

    FirebaseAuth firebaseAuth;
    String username, userEmail, userPhone, userpass;
    TextView resendOTP;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email_verification_admin);

        resendOTP = findViewById(R.id.resendOTPbtn);
        username = getIntent().getStringExtra("username");
        userEmail = getIntent().getStringExtra("useremail");
        userPhone = getIntent().getStringExtra("userphone");
        userpass = getIntent().getStringExtra("userpass");

        firebaseAuth = FirebaseAuth.getInstance();
        FirebaseAuth.getInstance().createUserWithEmailAndPassword(userEmail,userpass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task)
            {

                    Toast.makeText(EmailVerificationAdmin.this, "Admin created", Toast.LENGTH_SHORT).show();

                    FirebaseAuth.getInstance().getCurrentUser().sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>()
                    {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful())
                            {
                                Toast.makeText(EmailVerificationAdmin.this, "Verification Email Sent", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

                


                }

        });


        resendOTP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                FirebaseAuth.getInstance().getCurrentUser().sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {


                    }
                });

            }
        });


    }


    public void verifyEmailBtn(View view) {

        FirebaseUser firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        firebaseUser.reload();
        if (!firebaseUser.isEmailVerified())
        {
            Toast.makeText(this, "Please verify your email", Toast.LENGTH_SHORT).show();
        }
        else
        {
            User admin = new User(username, userpass, userEmail, userPhone, Boolean.TRUE);
            FirebaseDatabase.getInstance().getReference("Users")
                    .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                    .setValue(admin).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {

                            startActivity(new Intent(EmailVerificationAdmin.this, AdminHomePage.class));
                            finishAffinity();
                        }
                    });
        }
    }
}
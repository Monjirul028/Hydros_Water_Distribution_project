package com.example.waterdeliveryapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.Serializable;
import java.util.ArrayList;


public class userOrderAdapter extends FirebaseRecyclerAdapter<UserOrderModel , userOrderAdapter.MyViewHolder>{

    Context context;


    public userOrderAdapter(@NonNull FirebaseRecyclerOptions<UserOrderModel> options, Context context) {
        super(options);
        this.context = context;
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.single_order_user,parent,false);
        return new userOrderAdapter.MyViewHolder(v);
    }


    @SuppressLint("ResourceAsColor")
    @Override
    protected void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position, @NonNull UserOrderModel model) {
        holder.orderId.setText("Order id: "+model.getOrderId());
        holder.orderDate.setText(model.getDate());
        holder.orderStatus.setText(model.getStatus());

        holder.orderedProductTotal.setText("₹" + model.getTotalPrice()+"/-");

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, oderDetails.class);
                intent.putExtra("orderId", getRef(position).getKey());
                intent.putExtra("orderAmount", model.getTotalPrice());
                intent.putExtra("orderDate", model.getDate());
                intent.putExtra("orderStatus",model.getStatus());

                view.getContext().startActivity(intent);
            }
        });
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView orderId, orderStatus, orderedProductTotal,orderDate;

        public MyViewHolder(@NonNull View itemView) {

            super(itemView);
            orderId = (itemView).findViewById(R.id.orderId);
            orderStatus = (itemView).findViewById(R.id.orderStatus);
            orderDate = (itemView).findViewById(R.id.orderDate);
            orderedProductTotal = (itemView).findViewById(R.id.orderTotal);

        }
    }
}

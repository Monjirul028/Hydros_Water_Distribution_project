package com.example.waterdeliveryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class WelcomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
    }

    public  void btnSigninClicked(View view )
    {
        Intent signInintent = new Intent(WelcomeActivity.this, signInActivity.class);
        startActivity(signInintent);
    }
    public  void btnSignupClicked(View view )
    {
        Intent signupintent = new Intent(WelcomeActivity.this, signUpActivity.class);
        startActivity(signupintent);
    }
}
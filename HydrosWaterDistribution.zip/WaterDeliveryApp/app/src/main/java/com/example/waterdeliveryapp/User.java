package com.example.waterdeliveryapp;

import java.util.Comparator;

public class User {
    public String username,userpassword,useremail,userphoneno;
    Boolean userRole;



    public User()
    {

    }
    public User(String name, String pass, String email, String phno, Boolean role)
    {
        this.username = name;
        this.userpassword = pass;
        this.useremail = email;
        this.userphoneno = phno;
        this.userRole = role;
    }

    public  static Comparator <User> UserAtoZComparator = new Comparator<User>() {

        @Override
        public int compare(User user, User t1) {
            return user.getUsername().compareTo(t1.getUsername());
        }
    };

    public String getUserpassword() {
        return userpassword;
    }

    public String getUseremail() {
        return useremail;
    }

    public String getUserphoneno() {
        return userphoneno;
    }

    public String getUsername()
    {
        return username;
    }
    public Boolean getUserRole() {
        return userRole;
    }

    public void setUserRole( Boolean userRole) {
        this.userRole = userRole;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setUserpassword(String userpassword) {
        this.userpassword = userpassword;
    }

    public void setUseremail(String useremail) {
        this.useremail = useremail;
    }

    public void setUserphoneno(String userphoneno) {
        this.userphoneno = userphoneno;
    }
}

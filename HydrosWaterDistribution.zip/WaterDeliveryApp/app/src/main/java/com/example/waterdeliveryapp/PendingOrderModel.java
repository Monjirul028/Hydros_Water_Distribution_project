package com.example.waterdeliveryapp;

public class PendingOrderModel {


    addressModel model;
    Products products;
    String OrderId, Date, Status, Time, Total, UserId;

    public PendingOrderModel()
    {

    }
    public PendingOrderModel(addressModel model, Products products, String orderId, String date, String status, String time, String total, String userId) {
        this.model = model;
        this.products = products;
        OrderId = orderId;
        Date = date;
        Status = status;
        Time = time;
        Total = total;
        UserId = userId;
    }

    public addressModel getModel() {
        return model;
    }

    public void setModel(addressModel model) {
        this.model = model;
    }


    public Products getProducts() {
        return products;
    }

    public void setProducts(Products products) {
        this.products = products;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        Time = time;
    }

    public String getTotal() {
        return Total;
    }

    public void setTotal(String total) {
        Total = total;
    }

    public String getUserId() {
        return UserId;
    }

    public void setUserId(String userId) {
        UserId = userId;
    }

    public String getOrderId() {
        return OrderId;
    }

    public void setOrderId(String orderId) {
        this.OrderId = orderId;
    }
}

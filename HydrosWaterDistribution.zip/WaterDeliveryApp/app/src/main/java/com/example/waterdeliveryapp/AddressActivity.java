package com.example.waterdeliveryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class AddressActivity extends AppCompatActivity {

    EditText shopNameET, shopAreaET, shopStreetNameET, shopPhoneET, shopLandmarkET, shopPinET;
    String txtusername, txtpassword, txtemail, txtphoneno;
    ProgressBar pbar;

    String shopNameVar, shopAreaVar, shopStreetNameVar, shopPhoneVar, shopLandmarkVar, shopPinVar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_address);

        shopNameET = findViewById(R.id.shopName);
        shopAreaET = findViewById(R.id.Area);
        shopStreetNameET = findViewById(R.id.Street);
        shopPhoneET = findViewById(R.id.shopMobileNo);
        shopLandmarkET = findViewById(R.id.shopLandmark);
        shopPinET = findViewById(R.id.shopAreaPin);

        pbar = findViewById(R.id.progressbarAddressActivity);
        pbar.setVisibility(View.GONE);
        txtusername = getIntent().getStringExtra("username");
        txtemail = getIntent().getStringExtra("useremail");
        txtphoneno = getIntent().getStringExtra("userphone");
        txtpassword = getIntent().getStringExtra("userpass");
    }


    public void saveAddressBtn(View view) {

        pbar.setVisibility(View.VISIBLE);
        shopNameVar = shopNameET.getText().toString();
        shopAreaVar = shopAreaET.getText().toString();
        shopStreetNameVar = shopStreetNameET.getText().toString();
        shopLandmarkVar  = shopLandmarkET.getText().toString();
        shopPhoneVar = shopPhoneET.getText().toString();
        shopPinVar = shopPinET.getText().toString();

        if (shopNameVar.isEmpty())
        {
            shopNameET.setError("Enter shop name");
            shopNameET.requestFocus();
            pbar.setVisibility(View.GONE);

        }

        if (shopAreaVar.isEmpty() || shopNameVar.length()<5)
        {
            shopAreaET.setError("Enter valid area");
            shopAreaET.requestFocus();
            pbar.setVisibility(View.GONE);
        }

        if (shopStreetNameVar.isEmpty())
        {
            shopStreetNameET.setError("Enter street name");
            shopStreetNameET.requestFocus();
            pbar.setVisibility(View.GONE);

        }

        if (shopLandmarkVar.isEmpty())
        {
            shopLandmarkET.setError("Enter landmark");
            shopLandmarkET.requestFocus();
            pbar.setVisibility(View.GONE);
        }

        if (shopPhoneVar.isEmpty() || shopPhoneVar.length()<10)
        {
            shopPhoneET.setError("Enter Phone no");
            shopPhoneET.requestFocus();
            pbar.setVisibility(View.GONE);

        }

        if (shopPinVar.isEmpty() || shopPinVar.length()<6)
        {
            shopPinET.setError("Enter valid Pin");
            shopPinET.requestFocus();
            pbar.setVisibility(View.GONE);
        }
        else
        {
            Intent intent = new Intent(AddressActivity.this, otpVerification.class);
            intent.putExtra("username", txtusername);
            intent.putExtra("useremail", txtemail);
            intent.putExtra("userphone", txtphoneno);
            intent.putExtra("userpass", txtpassword);
            intent.putExtra("shopName",shopNameVar);
            intent.putExtra("shopArea", shopAreaVar);
            intent.putExtra("streetName",shopStreetNameVar);
            intent.putExtra("landmark", shopLandmarkVar);
            intent.putExtra("phone", shopPhoneVar);
            intent.putExtra("pin", shopPinVar);

            startActivity(intent);
        }
    }
}
package com.example.waterdeliveryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.deeplabstudio.fcmsend.FCMSend;
import com.example.waterdeliveryapp.databinding.ActivityHomePageBinding;
import com.google.android.material.navigation.NavigationBarView;

public class HomePage extends AppCompatActivity {



    ActivityHomePageBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        replaceFragment(new homefragment());

        binding = ActivityHomePageBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.bottomNavigationView.setOnItemReselectedListener(new NavigationBarView.OnItemReselectedListener() {
            @Override
            public void onNavigationItemReselected(@NonNull MenuItem item) {

            }
        });

        binding.bottomNavigationView.setOnItemSelectedListener(item -> {
            switch (item.getItemId())
            {
                case R.id.homebtn:
                    replaceFragment(new homefragment());
                    break;
                case R.id.profilebtn:
                    replaceFragment(new profileFragment());
                    break;
                case R.id.cartbtn:
                    replaceFragment(new cartFragment());
                    break;
            }
            return true;
        });
    }


    boolean doubleBackToExitPressedOnce = false;

    @Override
    public void onBackPressed() {


        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }



        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce=false;
            }
        }, 2000);

    }

    private void replaceFragment (Fragment fragment)
    {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.framelayout,fragment);
        fragmentTransaction.commit();
    }

    public void myOrderBtn(View view) {
        Intent intent = new Intent(HomePage.this, orderActivity.class);
        startActivity(intent);
    }
    public void addressBtnClkd(View view) {

        Intent intent1 = new Intent(HomePage.this , EditAddressUser.class);
        startActivity(intent1);
    }

    public void btnEditProfileClicked(View view){
        Intent intent = new Intent(HomePage.this, editProfile.class);
        startActivity(intent);
    }
    public void btnTermscondition(View view)
    {
        startActivity(new Intent(this, terms_and_conditions.class));
    }
    public void btnContactUs(View view) {
        startActivity(new Intent(this, contactUs.class));
    }
}
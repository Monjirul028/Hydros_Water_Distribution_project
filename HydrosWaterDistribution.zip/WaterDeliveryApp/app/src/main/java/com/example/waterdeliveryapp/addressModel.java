package com.example.waterdeliveryapp;

public class addressModel {


    String shopName,area,streetName,landmark, mobileNo,pin;

    public  addressModel()
    {

    }

    public addressModel(String shopName, String area, String streetName, String landmark, String mobileNo, String pin) {
        this.shopName = shopName;
        this.area = area;
        this.streetName = streetName;
        this.landmark = landmark;
        this.mobileNo = mobileNo;
        this.pin = pin;
    }


    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getStreetName() {
        return streetName;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    public String getLandmark() {
        return landmark;
    }

    public void setLandmark(String landmark) {
        this.landmark = landmark;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }
}

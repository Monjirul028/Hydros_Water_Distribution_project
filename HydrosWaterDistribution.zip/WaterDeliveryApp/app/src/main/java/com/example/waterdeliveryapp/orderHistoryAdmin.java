package com.example.waterdeliveryapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class orderHistoryAdmin extends AppCompatActivity {

    RecyclerView recyclerView;
    DatabaseReference databaseReference;
    DeliveredOrderAdapter deliveredOrderAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_history_admin);
        {

            recyclerView = (RecyclerView) findViewById(R.id.deliveredOrdersRV);
            LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
            layoutManager.setReverseLayout(true);
            layoutManager.setStackFromEnd(true);

            recyclerView.setLayoutManager(layoutManager);
            databaseReference = FirebaseDatabase.getInstance().getReference("DeliveredOrders");

            FirebaseRecyclerOptions<PendingOrderModel> options =
                    new FirebaseRecyclerOptions.Builder<PendingOrderModel>()
                            .setQuery(databaseReference, PendingOrderModel.class)
                            .build();

            deliveredOrderAdapter = new DeliveredOrderAdapter(options, this);
            recyclerView.setAdapter(deliveredOrderAdapter);

        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        deliveredOrderAdapter.startListening();
    }
}



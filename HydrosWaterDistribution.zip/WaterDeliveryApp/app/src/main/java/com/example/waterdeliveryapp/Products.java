package com.example.waterdeliveryapp;

import java.util.Comparator;

public class Products {

    String name;
    String size;
    String pricePerQuantity;
    String image;
    String price;
    String TotalPrice;
    String orderQuantity;

    public Products(String name, String size, String pricePerQuantity, String image, String price, String totalPrice, String orderQuantity) {
        this.name = name;
        this.size = size;
        this.pricePerQuantity = pricePerQuantity;
        this.image = image;
        this.price = price;
        TotalPrice = totalPrice;
        this.orderQuantity = orderQuantity;
    }

    public  static Comparator<Products> ProductsAtoZComparator = new Comparator<Products>() {

        @Override
        public int compare(Products user, Products t1) {
            return user.getName().compareTo(t1.getName());
        }
    };

    public String getTotalPrice() {
        return TotalPrice;
    }

    public void setTotalPrice(String totalPrice) {
        TotalPrice = totalPrice;
    }

    public String getOrderQuantity() {
        return orderQuantity;
    }

    public void setOrderQuantity(String orderQuantity) {
        this.orderQuantity = orderQuantity;
    }

    public Products()
    {

    }



    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getPricePerQuantity() {
        return pricePerQuantity;
    }

    public void setPricePerQuantity(String pricePerQuantity) {
        this.pricePerQuantity = pricePerQuantity;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image)
    {
        this.image = image;
    }

}

package com.example.waterdeliveryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.SignInMethodQueryResult;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.orhanobut.dialogplus.DialogPlus;
import com.orhanobut.dialogplus.ViewHolder;

public class editProfile extends AppCompatActivity {
    String uname, uPass, uEmail, uPhone;
    DatabaseReference myRef;
    DialogPlus dialogEmail,dialogPassword,dialogName,dialogPhoneNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        myRef = FirebaseDatabase.getInstance().getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid());

        dialogEmail = DialogPlus.newDialog(this)
                .setGravity(Gravity.CENTER)
                .setMargin(50, 0, 50, 0)
                .setContentHolder(new ViewHolder(R.layout.edit_email_dialog_box))
                .setExpanded(false)  // This will enable the expand feature, (similar to android L share dialog)
                .create();

        View holderView = dialogEmail.getHolderView();
        EditText emailETdialogBox = holderView.findViewById(R.id.emailETupdateEmailAdmin);
        emailETdialogBox.setText(FirebaseAuth.getInstance().getCurrentUser().getEmail());
        Button updateEmail = holderView.findViewById(R.id.updateEmail);
        updateEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                FirebaseAuth.getInstance().fetchSignInMethodsForEmail(emailETdialogBox.getText().toString())
                        .addOnCompleteListener(new OnCompleteListener<SignInMethodQueryResult>() {
                            @Override
                            public void onComplete(@NonNull Task<SignInMethodQueryResult> task) {

                                boolean isNewUser = task.getResult().getSignInMethods().isEmpty();

                                if (isNewUser) {
                                    FirebaseAuth.getInstance().getCurrentUser().verifyBeforeUpdateEmail(emailETdialogBox.getText().toString()).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {

                                            Toast.makeText(editProfile.this, "Please verify your email", Toast.LENGTH_SHORT).show();
                                        }
                                    });

                                }
                                else {
                                    emailETdialogBox.setError("Email is already taken");
                                    emailETdialogBox.requestFocus();                                }
                            }
                        });


            }
        });


        dialogPassword = DialogPlus.newDialog(this)
                .setGravity(Gravity.CENTER)
                .setMargin(50, 0, 50, 0)
                .setContentHolder(new ViewHolder(R.layout.edit_password_admin))
                .setExpanded(false)  // This will enable the expand feature, (similar to android L share dialog)
                .create();
        View holderViewPass = dialogPassword.getHolderView();
        EditText pass = holderViewPass.findViewById(R.id.password_editText);
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                pass.setText(snapshot.child("userpassword").getValue().toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        Button updatePassword = holderViewPass.findViewById(R.id.updatePassword);
        updatePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (pass.getText().toString().isEmpty() || pass.getText().toString().length() < 6)
                {
                    pass.setError("Enter valid password");
                }
                else
                {
                    String value = pass.getText().toString();
                    FirebaseAuth.getInstance().getCurrentUser().updatePassword(value).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            dialogPassword.dismiss();
                            Toast.makeText(editProfile.this, "Password changed", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });


        dialogName = DialogPlus.newDialog(this)
                .setGravity(Gravity.CENTER)
                .setMargin(50, 0, 50, 0)
                .setContentHolder(new ViewHolder(R.layout.edit_name_admin))
                .setExpanded(false)  // This will enable the expand feature, (similar to android L share dialog)
                .create();
        View holderViewName = dialogName.getHolderView();
        EditText  name = holderViewName.findViewById(R.id.updateNameET);
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                name.setText(snapshot.child("username").getValue().toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        Button updateName = holderViewName.findViewById(R.id.updateName);
        updateName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (name.getText().toString().isEmpty()) {
                    name.setError("Enter a name");
                }
                else
                {
                    FirebaseDatabase.getInstance().getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                            .child("username").setValue(name.getText().toString()).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    dialogName.dismiss();
                                    Toast.makeText(editProfile.this, "Name changed", Toast.LENGTH_SHORT).show();
                                }
                            });
                }
            }
        });

        dialogPhoneNo = DialogPlus.newDialog(this)
                .setGravity(Gravity.CENTER)
                .setMargin(50, 0, 50, 0)
                .setContentHolder(new ViewHolder(R.layout.edit_ph_admin))
                .setExpanded(false)  // This will enable the expand feature, (similar to android L share dialog)
                .create();

        View holderViewPhone = dialogPhoneNo.getHolderView();
        EditText  phone = holderViewPhone.findViewById(R.id.updatePhoneET);
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                phone.setText(snapshot.child("userphoneno").getValue().toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        Button updatePhone = holderViewPhone.findViewById(R.id.updatePhoneNoAmin);
        updatePhone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (phone.getText().toString().isEmpty() || phone.getText().toString().length()<10)
                {
                    phone.setError("Enter valid Phone no");
                }
                else
                {
                    FirebaseDatabase.getInstance().getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                            .child("userphoneno").setValue( phone.getText().toString()).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    dialogPhoneNo.dismiss();
                                    Toast.makeText(editProfile.this, "Phone no changed", Toast.LENGTH_SHORT).show();
                                }
                            });

                }

            }
        });


        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                uname = snapshot.child("username").getValue().toString();
                uPass = snapshot.child("userpassword").getValue().toString();
                uEmail = snapshot.child("useremail").getValue().toString();
                uPhone = snapshot.child("userphoneno").getValue().toString();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }

    public void resetPasswordBtn(View view) {
        dialogPassword.show();
    }

    public void resetEmailBtn(View view) {
        dialogEmail.show();

    }
    public void changeAdminNameBtn(View view) {
        dialogName.show();
    }

    public void changeAdminPhoneNoBtn(View view) {
        dialogPhoneNo.show();
    }



}
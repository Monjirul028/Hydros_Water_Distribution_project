package com.example.waterdeliveryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;

import com.google.firebase.auth.FirebaseAuth;

public class AdminRegistration extends AppCompatActivity {

    EditText etxtusername, etxtpassword, etxtphoneno, etxtemail;
    Button signUPButton;
    ProgressBar progressBar ;
    private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_registration);

        signUPButton = findViewById(R.id.verifyBtn);
        progressBar = findViewById(R.id.progressBarsignUp);
        progressBar.setVisibility(View.GONE);
        mAuth = FirebaseAuth.getInstance();
        etxtusername = findViewById(R.id.ETusername);
        etxtpassword = findViewById(R.id.ETpassword);
        etxtemail = findViewById(R.id.ETemail);
        etxtphoneno = findViewById(R.id.ETphoneNo);
    }

    public void AdminSignUpBtn(View view) {

        progressBar.setVisibility(View.VISIBLE);
        String txtusername = etxtusername.getText().toString().trim();
        String txtpassword = etxtpassword.getText().toString().trim();
        String txtemail = etxtemail.getText().toString().trim();
        String txtphoneno = etxtphoneno.getText().toString().trim();

        if (txtusername.isEmpty()) {
            etxtusername.setError("Enter username");
            etxtusername.requestFocus();
            progressBar.setVisibility(View.GONE);
        }
        if (txtpassword.isEmpty()) {
            etxtpassword.setError("Enter password");
            etxtpassword.requestFocus();
            progressBar.setVisibility(View.GONE);

        }
        if(txtpassword.length() < 6 )
        {
            etxtpassword.setError("Enter at-least 6 characters");
        }
        if (txtemail.isEmpty()) {
            etxtemail.setError("Enter email");
            etxtemail.requestFocus();
            progressBar.setVisibility(View.GONE);

        }
        if (txtphoneno.isEmpty()) {
            etxtphoneno.setError("Enter phone no");
            etxtphoneno.requestFocus();
            progressBar.setVisibility(View.GONE);
        }

        else
        {

            progressBar.setVisibility(View.GONE);
            Intent intent = new Intent(AdminRegistration.this ,EmailVerificationAdmin.class);
            intent.putExtra("username", txtusername);
            intent.putExtra("useremail", txtemail);
            intent.putExtra("userphone", txtphoneno);
            intent.putExtra("userpass", txtpassword);

            startActivity(intent);
        }
    };
}
package com.example.waterdeliveryapp;


import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Collections;

public class viewProducts extends AppCompatActivity {
    RecyclerView recyclerView;
    DatabaseReference databaseReference;
    ProductAdapter productAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_products);

        recyclerView = (RecyclerView) findViewById(R.id.view_products_Rv);
        databaseReference = FirebaseDatabase.getInstance().getReference("Products");
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        FirebaseRecyclerOptions<Products> options =
                new FirebaseRecyclerOptions.Builder<Products>()
                        .setQuery(databaseReference, Products.class)
                        .build();


         productAdapter = new ProductAdapter(options,this);
         recyclerView.setAdapter(productAdapter);

    }

    @Override
    protected void onStart() {
        super.onStart();
        productAdapter.startListening();
    }

}
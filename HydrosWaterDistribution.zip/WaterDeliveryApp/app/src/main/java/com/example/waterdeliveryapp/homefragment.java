package com.example.waterdeliveryapp;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ScrollView;
import android.widget.Toast;

import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.models.SlideModel;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;


public class homefragment extends Fragment {
    ImageSlider imageSlider;
    RecyclerView recyclerView;
    DatabaseReference databaseReference;
    ProductAdapterUser productAdapterUser;

    public homefragment() {

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_homefragment, container, false);
        imageSlider = view.findViewById(R.id.image_slider);
        ArrayList<SlideModel> imageList = new ArrayList<>();
        imageList.add(new SlideModel(R.drawable.slideone, null));
        imageList.add(new SlideModel(R.drawable.slidetwo, null));
        imageList.add(new SlideModel(R.drawable.slidethree, null));
        imageSlider.setImageList(imageList);

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), 2 , LinearLayoutManager.VERTICAL, false );
        recyclerView = (RecyclerView) getActivity().findViewById(R.id.homefragmentRecyclerView);
        recyclerView.setNestedScrollingEnabled(false);
        databaseReference = FirebaseDatabase.getInstance().getReference("Products");
        recyclerView.setLayoutManager(gridLayoutManager);

        FirebaseRecyclerOptions<Products> options =
                new FirebaseRecyclerOptions.Builder<Products>()
                        .setQuery(databaseReference, Products.class)
                        .build();
        productAdapterUser = new ProductAdapterUser(options,getActivity());
        recyclerView.setAdapter(productAdapterUser);
    }

    @Override
    public void onStart() {
        super.onStart();
        productAdapterUser.startListening();
    }
}
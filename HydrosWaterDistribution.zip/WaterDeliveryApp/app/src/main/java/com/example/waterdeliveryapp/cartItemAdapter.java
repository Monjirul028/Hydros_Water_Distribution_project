package com.example.waterdeliveryapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;


public class cartItemAdapter extends FirebaseRecyclerAdapter<Products, cartItemAdapter.MyViewHolder> {

   private Context context;
    public cartItemAdapter(@NonNull FirebaseRecyclerOptions<Products> options , Context context) {
        super(options);
        this.context = context;
    }

    @Override
    protected void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position, @NonNull Products products) {


        DatabaseReference TotalAmountRef = FirebaseDatabase.getInstance().getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid());
        DatabaseReference itemRef = FirebaseDatabase.getInstance().getReference("Cart").child(FirebaseAuth.getInstance().getCurrentUser().getUid().toString())
                .child(getRef(position).getKey());

        holder.productName.setText(products.getName()+" (" + products.getSize() +")");
        holder.productPrice.setText("₹" + products.getPrice()+"/-" + products.getPricePerQuantity());
        holder.itemTotalPrice.setText( "Total: ₹"+products.getTotalPrice());
        holder.itemCounter.setText(products.getOrderQuantity());
        Picasso.get().load(products.getImage()).into(holder.productImage);

        holder.counterPlus.setOnClickListener(new View.OnClickListener() {

            int totalamount = 0;
            @Override
            public void onClick(View view) {

                products.setOrderQuantity(String.valueOf(Integer.valueOf(products.getOrderQuantity())+1));

                products.setTotalPrice(String.valueOf(   Integer.valueOf(products.getOrderQuantity()) *   Integer.valueOf(products.getPrice())  ));

                itemRef.setValue(products);

                TotalAmountRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        totalamount = Integer.valueOf(snapshot.child("TotalAmount").getValue().toString());

                        TotalAmountRef.child("TotalAmount").setValue(String .valueOf(totalamount+ Integer.valueOf(products.getPrice())));
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });

        holder.counterMinus.setOnClickListener(new View.OnClickListener() {
            int totalamount = 0;
            @Override
            public void onClick(View view) {

                if (Integer.valueOf(products.getOrderQuantity()) > 1)
                {
                    products.setOrderQuantity(String.valueOf(Integer.valueOf(products.getOrderQuantity()) - 1));

                    products.setTotalPrice(String.valueOf(Integer.valueOf(products.getOrderQuantity()) * Integer.valueOf(products.getPrice())));

                    itemRef.setValue(products);

                    TotalAmountRef.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            totalamount = Integer.valueOf(snapshot.child("TotalAmount").getValue().toString());

                            TotalAmountRef.child("TotalAmount").setValue(String.valueOf(totalamount - Integer.valueOf(products.getPrice())));
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }


            }
        });

        holder.removeProductBtn.setOnClickListener(new View.OnClickListener() {
            int totalamount = 0;
            @Override
            public void onClick(View view) {
                itemRef.setValue(null);
                TotalAmountRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        totalamount = Integer.valueOf(snapshot.child("TotalAmount").getValue().toString());

                        TotalAmountRef.child("TotalAmount").setValue(String.valueOf(totalamount - Integer.valueOf(products.getTotalPrice())));
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

            }
        });
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.cart_item_design,parent,false);
        return new cartItemAdapter.MyViewHolder(v);
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView productName, productPrice,  itemCounter,itemTotalPrice,grandTotalPrice;
        ImageView counterPlus, counterMinus;
        ImageView productImage,removeProductBtn;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            productName = itemView.findViewById(R.id.cartItemNameTV);
            productPrice = itemView.findViewById(R.id.cartItemPriceTV);
            removeProductBtn = itemView.findViewById(R.id.cartItemDeleteBtn);
            itemCounter = itemView.findViewById(R.id.cartItemCoutnerTV);
            counterMinus = itemView.findViewById(R.id.cartItemMinusBtn);
            counterPlus = itemView.findViewById(R.id.cartItemPlusBtn);
            productImage = itemView.findViewById(R.id.cartItemImage);
            itemTotalPrice = itemView.findViewById(R.id.cartItemTotalPriceTV);
            grandTotalPrice = itemView.findViewById(R.id.TotalAmountTV);
        }
    }
}

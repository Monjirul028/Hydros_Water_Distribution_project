
package com.example.waterdeliveryapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class oderDetails extends AppCompatActivity {
    TextView orderIDTv, orderAmountTv, orderDateTv, orderStatusTv;
    String orderID,orderAmount,orderDate, orderStatus;
    RecyclerView recyclerView;
    DatabaseReference databaseReference;
    OrderItemAdapter orderItemAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oder_details);

        orderIDTv = findViewById(R.id.orderIDtvOD);
        orderAmountTv = findViewById(R.id.orderPricetvOD);
        recyclerView = findViewById(R.id.orderDetailsRV);
        orderDateTv = findViewById(R.id.orderDatetvOD);
        orderStatusTv = findViewById(R.id.orderStatustvOD);
        orderID = getIntent().getStringExtra("orderId");
        orderAmount = getIntent().getStringExtra("orderAmount");
        orderDate = getIntent().getStringExtra("orderDate");
        orderStatus = getIntent().getStringExtra("orderStatus");

            orderIDTv.setText("\t\t\tOrder ID:      "+orderID);
        orderAmountTv.setText("\t\t\t\tAmount:      "+orderAmount);
          orderDateTv.setText("Ordered On:      "+orderDate);
        orderStatusTv.setText("\t\t\t\t\tStatus:      "+orderStatus);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        databaseReference = FirebaseDatabase.getInstance().getReference("Orders")
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                .child(orderID).child("Items");

        FirebaseRecyclerOptions<Products> options =
                new FirebaseRecyclerOptions.Builder<Products>()
                        .setQuery(databaseReference,Products.class)
                        .build();
        orderItemAdapter = new OrderItemAdapter(options, this);
        recyclerView.setAdapter(orderItemAdapter);
    }

    @Override
    protected void onStart() {
        super.onStart();
        orderItemAdapter.startListening();
    }


}
package com.example.waterdeliveryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.SignInMethodQueryResult;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.orhanobut.dialogplus.DialogPlus;
import com.orhanobut.dialogplus.ViewHolder;

public class AdminProfile extends AppCompatActivity {
    TextView adminNameTv, AdminEmailTv, AdminPhoneNoTv;
    String AdminName;
    EditText emailETdialogBox;
    EditText pass;
    DialogPlus dialogEmail,dialogPassword,dialogName,dialogPhoneNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_profile);
        adminNameTv = findViewById(R.id.AdminName);
        AdminEmailTv = findViewById(R.id.adminEmail);
        AdminPhoneNoTv = findViewById(R.id.adminPhoneNo);


         dialogEmail = DialogPlus.newDialog(this)
                .setGravity(Gravity.CENTER)
                .setMargin(50, 0, 50, 0)
                .setContentHolder(new ViewHolder(R.layout.edit_email_dialog_box))
                .setExpanded(false)  // This will enable the expand feature, (similar to android L share dialog)
                .create();

        View holderView = dialogEmail.getHolderView();
        emailETdialogBox = holderView.findViewById(R.id.emailETupdateEmailAdmin);
       Button updateEmail = holderView.findViewById(R.id.updateEmail);
        updateEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                FirebaseAuth.getInstance().fetchSignInMethodsForEmail(emailETdialogBox.getText().toString())
                        .addOnCompleteListener(new OnCompleteListener<SignInMethodQueryResult>() {
                            @Override
                            public void onComplete(@NonNull Task<SignInMethodQueryResult> task) {

                                boolean isNewUser = task.getResult().getSignInMethods().isEmpty();

                                if (isNewUser) {
                                    FirebaseAuth.getInstance().getCurrentUser().verifyBeforeUpdateEmail(emailETdialogBox.getText().toString()).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {

                                            Toast.makeText(AdminProfile.this, "Please verify your email", Toast.LENGTH_SHORT).show();
                                        }
                                    });

                                }
                                else {
                                        emailETdialogBox.setError("Email is already taken");
                                        emailETdialogBox.requestFocus();
                                }
                            }
                        });



            }
        });


        dialogPassword = DialogPlus.newDialog(this)
                .setGravity(Gravity.CENTER)
                .setMargin(50, 0, 50, 0)
                .setContentHolder(new ViewHolder(R.layout.edit_password_admin))
                .setExpanded(false)  // This will enable the expand feature, (similar to android L share dialog)
                .create();
        View holderViewPass = dialogPassword.getHolderView();
        pass = holderViewPass.findViewById(R.id.password_editText);
        Button updatePassword = holderViewPass.findViewById(R.id.updatePassword);
        updatePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (pass.getText().toString().isEmpty() || pass.getText().toString().length() < 6)
                {
                    pass.setError("Enter valid password");
                }
                else
                {
                    String value = pass.getText().toString();
                    FirebaseAuth.getInstance().getCurrentUser().updatePassword(value).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            dialogPassword.dismiss();
                            Toast.makeText(AdminProfile.this, "Password changed", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });


        dialogName = DialogPlus.newDialog(this)
                .setGravity(Gravity.CENTER)
                .setMargin(50, 0, 50, 0)
                .setContentHolder(new ViewHolder(R.layout.edit_name_admin))
                .setExpanded(false)  // This will enable the expand feature, (similar to android L share dialog)
                .create();
        View holderViewName = dialogName.getHolderView();
        EditText  name = holderViewName.findViewById(R.id.updateNameET);
        Button updateName = holderViewName.findViewById(R.id.updateName);
        updateName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (name.getText().toString().isEmpty()) {
                    name.setError("Enter a name");
                }
                else
                {
                    FirebaseDatabase.getInstance().getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                            .child("username").setValue(name.getText().toString()).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    dialogName.dismiss();
                                    Toast.makeText(AdminProfile.this, "Name changed", Toast.LENGTH_SHORT).show();
                                }
                            });
                }
            }
        });

        dialogPhoneNo = DialogPlus.newDialog(this)
                .setGravity(Gravity.CENTER)
                .setMargin(50, 0, 50, 0)
                .setContentHolder(new ViewHolder(R.layout.edit_ph_admin))
                .setExpanded(false)  // This will enable the expand feature, (similar to android L share dialog)
                .create();

        View holderViewPhone = dialogPhoneNo.getHolderView();
        EditText  phone = holderViewPhone.findViewById(R.id.updatePhoneET);
        Button updatePhone = holderViewPhone.findViewById(R.id.updatePhoneNoAmin);
        updatePhone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (phone.getText().toString().isEmpty() || phone.getText().toString().length()<10)
                {
                    phone.setError("Enter valid Phone no");
                }
                else
                {
                    FirebaseDatabase.getInstance().getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                            .child("userphoneno").setValue( phone.getText().toString()).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    dialogPhoneNo.dismiss();
                                    Toast.makeText(AdminProfile.this, "Phone no changed", Toast.LENGTH_SHORT).show();
                                }
                            });

                }

            }
        });

        FirebaseDatabase.getInstance().getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                       adminNameTv.setText( snapshot.child("username").getValue(String.class));

                        AdminPhoneNoTv.setText( snapshot.child("userphoneno").getValue(String.class));
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
        String email = FirebaseAuth.getInstance().getCurrentUser().getEmail();
        AdminEmailTv.setText(email);

    }
    public void AdminLogOutBtn (View v)
    {
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which){
                    case DialogInterface.BUTTON_POSITIVE:
                        FirebaseAuth.getInstance().signOut();
                        Toast.makeText(AdminProfile.this, "Logging out", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(AdminProfile.this, WelcomeActivity.class);
                        startActivity(intent);
                        finishAffinity();

                        break;

                    case DialogInterface.BUTTON_NEGATIVE:

                        break;
                }
            }
        };
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Are you sure?").setPositiveButton("Yes", dialogClickListener)
                .setNegativeButton("No", dialogClickListener).show();

    }

    public void newAdminRegistrationBtn(View view) {
        startActivity(new Intent(this, LogOutActivity.class));
    }

    public void resetPasswordBtn(View view) {
        dialogPassword.show();
    }

    public void resetEmailBtn(View view) {
        dialogEmail.show();

    }
    public void changeAdminNameBtn(View view) {
        dialogName.show();
    }

    public void changeAdminPhoneNoBtn(View view) {
        dialogPhoneNo.show();
    }


}